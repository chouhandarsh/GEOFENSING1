
Geofence Student Attendance App (Android Project)
------------------------------------------------
This is an Android Studio project, not a ready APK.

How to build:
1. Open this project in Android Studio.
2. Sync Gradle and build.
3. Run on device or generate APK (Build > Build APK).

Coordinates preset:
- Latitude: 15.4426448
- Longitude: 75.0260553
- Geofence radius: 30m

Backend endpoint placeholder: http://127.0.0.1:5000/mark
Change it in MainActivity.kt before building.

Admin backend runs separately (Flask).
